jQuery(document).ready(function($) {

	/* Default Banner Start */

	jQuery(".default-banner").owlCarousel({
	    items:1,
	    loop:true,
	    smartSpeed:450,
	    nav:false
	})

	/* Default Banner End */


	/* Default Banner Start */

	jQuery(".default-banner").owlCarousel({
	    items:1,
	    loop:true,
	    smartSpeed:450,
	    nav:false
	})

	/* Default Banner End */


	/* Default Banner Start */

	jQuery(".default-banner").owlCarousel({
	    items:1,
	    loop:true,
	    smartSpeed:450,
	    nav:false
	})

	/* Default Banner End */


	/* Default Banner Start */

	jQuery(".default-banner").owlCarousel({
	    items:1,
	    loop:true,
	    smartSpeed:450,
	    nav:false
	})

	/* Default Banner End */


	/* Default Banner Start */

	jQuery(".default-banner").owlCarousel({
	    items:1,
	    loop:true,
	    smartSpeed:450,
	    nav:false
	})

	/* Default Banner End */

});